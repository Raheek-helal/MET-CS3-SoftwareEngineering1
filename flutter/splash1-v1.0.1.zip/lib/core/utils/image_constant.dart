class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Splash images
  static String imgUndrawJudgeKa = '$imagePath/img_undraw_judge_ka.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
