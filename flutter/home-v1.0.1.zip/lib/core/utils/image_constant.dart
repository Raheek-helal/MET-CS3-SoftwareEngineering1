class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Home images
  static String imgImage9 = '$imagePath/img_image_9.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
